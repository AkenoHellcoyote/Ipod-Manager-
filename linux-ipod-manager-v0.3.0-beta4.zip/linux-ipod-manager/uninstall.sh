#!/usr/bin/env bash
set -e
rm -rf "$HOME/.local/lib/linux-ipod-manager"
rm -f "$HOME/.local/bin/ipod-manager"
rm -f "$HOME/.local/share/applications/linux-ipod-manager.desktop"
echo "Linux iPod Manager removed."
