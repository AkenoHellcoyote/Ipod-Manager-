#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

ARCH="$(uname -m)"
if [ "$ARCH" != "x86_64" ]; then
    echo "This AppImage build currently targets x86_64."
    exit 1
fi

for cmd in python3 gcc pkg-config curl ffmpeg ffprobe; do
    command -v "$cmd" >/dev/null || {
        echo "Missing required build command: $cmd"
        exit 1
    }
done

pkg-config --exists libgpod-1.0 gdk-pixbuf-2.0 || {
    echo "Missing development metadata for libgpod/gdk-pixbuf."
    exit 1
}

rm -rf build dist AppDir
mkdir -p \
    AppDir/usr/bin/ipod-manager \
    AppDir/usr/share/applications \
    AppDir/usr/share/icons/hicolor/scalable/apps

# Build the native libgpod backend.
gcc -O2 -Wall -Wextra \
    -o AppDir/usr/bin/ipod-manager/ipod-media-helper \
    src/ipod-media-helper.c \
    $(pkg-config --cflags --libs libgpod-1.0 gdk-pixbuf-2.0)

# Build the Python GUI. PyInstaller bundles Python/Tk and Python modules.
python3 -m venv .build-venv
.build-venv/bin/pip install --upgrade pip pyinstaller

.build-venv/bin/pyinstaller \
    --noconfirm \
    --clean \
    --onedir \
    --name ipod-manager \
    src/ipod-manager.py

cp -a dist/ipod-manager/. AppDir/usr/bin/ipod-manager/

# Runtime media tools used by the GUI.
cp "$(command -v ffmpeg)" AppDir/usr/bin/ffmpeg
cp "$(command -v ffprobe)" AppDir/usr/bin/ffprobe

# Desktop integration.
cp resources/linux-ipod-manager.svg \
   AppDir/usr/share/icons/hicolor/scalable/apps/linux-ipod-manager.svg

sed -e 's#^Icon=.*#Icon=linux-ipod-manager#' \
    -e 's#^Exec=.*#Exec=linux-ipod-manager#' \
    desktop/linux-ipod-manager.desktop \
    > AppDir/usr/share/applications/linux-ipod-manager.desktop

# AppImage entry point.
cat > AppDir/AppRun <<'EOF'
#!/bin/sh
HERE="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
export PATH="$HERE/usr/bin:$HERE/usr/bin/ipod-manager:$PATH"
exec "$HERE/usr/bin/ipod-manager/ipod-manager" "$@"
EOF
chmod +x AppDir/AppRun

# Obtain maintained official AppImage tools.
if [ ! -x "$ROOT/linuxdeploy-x86_64.AppImage" ]; then
    curl -fL \
      -o "$ROOT/linuxdeploy-x86_64.AppImage" \
      https://github.com/linuxdeploy/linuxdeploy/releases/download/continuous/linuxdeploy-x86_64.AppImage
    chmod +x "$ROOT/linuxdeploy-x86_64.AppImage"
fi

if [ ! -x "$ROOT/appimagetool-x86_64.AppImage" ]; then
    curl -fL \
      -o "$ROOT/appimagetool-x86_64.AppImage" \
      https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage
    chmod +x "$ROOT/appimagetool-x86_64.AppImage"
fi

# Deploy native runtime libraries for the C helper and ffmpeg tools.
./linuxdeploy-x86_64.AppImage \
    --appdir AppDir \
    --desktop-file AppDir/usr/share/applications/linux-ipod-manager.desktop \
    --icon-file AppDir/usr/share/icons/hicolor/scalable/apps/linux-ipod-manager.svg \
    --executable AppDir/usr/bin/ipod-manager/ipod-media-helper \
    --executable AppDir/usr/bin/ffmpeg \
    --executable AppDir/usr/bin/ffprobe

VERSION="$(tr -d '\n' < VERSION)"

ARCH=x86_64 ./appimagetool-x86_64.AppImage \
    AppDir \
    "Linux-iPod-Manager-${VERSION}-x86_64.AppImage"

echo
echo "Built: Linux-iPod-Manager-${VERSION}-x86_64.AppImage"
