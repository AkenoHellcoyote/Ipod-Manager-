# Contributing

Bug reports and pull requests are welcome.

## Before testing

Always test with a backup iPod or a full backup of the iPod database.

Never test a new backend on the only copy of important media.

## Code

The project currently uses:

- Python for the GUI
- C + libgpod for iPod database operations

Keep filesystem/database writes in the backend where possible so additional iPod formats can later be implemented without rewriting the GUI.
