#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
BIN_DIR="$HOME/.local/bin"
LIB_DIR="$HOME/.local/lib/linux-ipod-manager"
APP_DIR="$HOME/.local/share/applications"

echo "Installing Linux iPod Manager..."

install_debian() {
    local missing=()
    for pkg in python3 python3-tk gcc pkg-config libgpod-dev libgdk-pixbuf-2.0-dev ffmpeg; do
        if ! dpkg -s "$pkg" >/dev/null 2>&1; then
            missing+=("$pkg")
        fi
    done
    if [ "${#missing[@]}" -gt 0 ]; then
        echo
        echo "Missing packages: ${missing[*]}"
        echo "Install them with:"
        echo "  sudo apt update && sudo apt install ${missing[*]}"
        exit 1
    fi
}

install_fedora() {
    local missing=()
    for pkg in python3 python3-tkinter gcc pkgconf-pkg-config libgpod-devel gdk-pixbuf2-devel ffmpeg; do
        if ! rpm -q "$pkg" >/dev/null 2>&1; then
            missing+=("$pkg")
        fi
    done
    if [ "${#missing[@]}" -gt 0 ]; then
        echo
        echo "Missing Fedora packages: ${missing[*]}"
        echo "Install them with:"
        echo "  sudo dnf install ${missing[*]}"
        exit 1
    fi
}

install_arch() {
    local missing=()
    # Names vary less on Arch; libgpod may be provided by a repo/AUR package.
    for pkg in python tk gcc pkgconf ffmpeg; do
        if ! pacman -Q "$pkg" >/dev/null 2>&1; then
            missing+=("$pkg")
        fi
    done
    if ! pacman -Q libgpod >/dev/null 2>&1; then
        missing+=("libgpod")
    fi
    if [ "${#missing[@]}" -gt 0 ]; then
        echo
        echo "Missing Arch packages: ${missing[*]}"
        echo "Install the official packages with:"
        echo "  sudo pacman -S ${missing[*]}"
        echo "If libgpod is not available in your configured repositories, use the appropriate Arch/AUR package."
        exit 1
    fi
}

if command -v apt >/dev/null 2>&1 && command -v dpkg >/dev/null 2>&1; then
    echo "Checking Debian/Ubuntu/Zorin packages..."
    install_debian
elif command -v dnf >/dev/null 2>&1 && command -v rpm >/dev/null 2>&1; then
    echo "Checking Fedora packages..."
    install_fedora
elif command -v pacman >/dev/null 2>&1; then
    echo "Checking Arch Linux packages..."
    install_arch
else
    echo
    echo "Unsupported package manager."
    echo "Install the requirements listed in README.md manually, then rerun this installer."
    exit 1
fi

mkdir -p "$BIN_DIR" "$LIB_DIR" "$APP_DIR"

cp "$PROJECT_DIR/src/ipod-manager.py" "$LIB_DIR/ipod-manager.py"
cp "$PROJECT_DIR/src/ipod-media-helper.c" "$LIB_DIR/ipod-media-helper.c"

gcc -O2 -Wall -Wextra \
    -o "$LIB_DIR/ipod-media-helper" \
    "$LIB_DIR/ipod-media-helper.c" \
    $(pkg-config --cflags --libs libgpod-1.0 gdk-pixbuf-2.0)

cp "$PROJECT_DIR/resources/linux-ipod-manager.svg" "$LIB_DIR/linux-ipod-manager.svg"

cat > "$BIN_DIR/ipod-manager" <<EOF
#!/usr/bin/env bash
exec /usr/bin/python3 "$LIB_DIR/ipod-manager.py" "\$@"
EOF
chmod +x "$BIN_DIR/ipod-manager"

cat > "$APP_DIR/linux-ipod-manager.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=Linux iPod Manager
Comment=Manage music and audiobooks on classic iPods
Exec=$BIN_DIR/ipod-manager
Icon=$LIB_DIR/linux-ipod-manager.svg
Terminal=false
Categories=AudioVideo;Audio;Utility;
StartupNotify=true
EOF

echo
echo "Installation complete."
echo "Launch 'Linux iPod Manager' from your application menu."
