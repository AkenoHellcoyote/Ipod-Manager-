# Linux iPod Manager

A small, open-source GTK/Tk desktop application for managing music and audiobooks on classic iPods from Linux.

The project is designed around **libgpod**, so it works with the iPod database instead of simply copying files into `iPod_Control/Music`.

## Goals

- Add MP3 music to a classic iPod
- Add M4B audiobooks as real audiobooks
- Read embedded metadata and cover artwork
- Delete selected tracks
- Delete all music, all audiobooks, or all media
- Detect common mounted iPods automatically
- Identify the iPod through libgpod and gate write operations by compatibility
- Keep the GUI usable for people who do not want to use a terminal
- Provide a backend architecture that can later support additional non-iOS iPod formats

## Important compatibility note

The project deliberately targets **non-iOS iPods**.

That includes the classic iPod family, iPod mini, and many iPod nano/shuffle generations. However, **not every non-iOS model is currently writable through libgpod 0.8.3**.

In particular:

- iPod classic / video / older nano generations: primary target
- iPod nano 3G and 4G: libgpod-compatible
- iPod nano 5G: special/partial support; may require an iTunes-initialized database
- iPod nano 6G: not supported by libgpod 0.8.3
- iPod nano 7G: requires a separate backend
- iPod touch / iPhone / iPad: intentionally outside the project scope because they use the iOS media model

The application should therefore **refuse unsupported devices rather than risk corrupting their database**.

## Requirements

Debian/Ubuntu/Zorin:

```bash
sudo apt update
sudo apt install python3 python3-tk gcc pkg-config libgpod-dev ffmpeg
```

The application uses:

- Python 3
- Tkinter
- libgpod 0.8.x
- ffmpeg/ffprobe
- a small C helper for database operations

## Installation

Run:

```bash
./install.sh
```

Then start **Linux iPod Manager** from the application menu.

A per-user installation is used, so the program does not need to be installed system-wide.


## Portable distribution

The project contains a GitHub Actions workflow for building an x86_64 AppImage. AppImages can package an application and its dependencies into a single file; this project uses linuxdeploy for AppDir preparation and appimagetool for the final image. citeturn358564search5turn358564search6

The AppImage pipeline is still considered beta until the resulting image has been tested on multiple Linux distributions.


### AppImage status

The AppImage build bundles the Python application, the native libgpod helper, and the ffmpeg/ffprobe runtime used by the GUI. It is a **beta packaging target** and still needs testing on several Linux distributions before being advertised as universal.

## Development

Build the helper manually:

```bash
gcc -O2 -Wall -Wextra -o src/ipod-media-helper src/ipod-media-helper.c \
    $(pkg-config --cflags --libs libgpod-1.0)
```

Run the GUI directly:

```bash
python3 src/ipod-manager.py
```

## Safety

Always keep a backup of important iPod content.

The program modifies the iPod's iTunesDB. A failure during a write can potentially damage the database, especially on old hardware.

The project intentionally avoids writing to devices it cannot identify as compatible.

## License

GPL-3.0-only


## Building the AppImage locally

On an x86_64 Debian/Ubuntu/Zorin system with the build dependencies installed:

```bash
./packaging/build-appimage.sh
```

The resulting `Linux-iPod-Manager-0.3.0-beta3-x86_64.AppImage` is a beta build and should be tested on the target distribution before release.
