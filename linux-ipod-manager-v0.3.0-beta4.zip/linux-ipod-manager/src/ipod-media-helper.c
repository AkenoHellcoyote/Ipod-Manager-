#include <gpod/itdb.h>
#include <glib.h>
#include <glib/gstdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static void print_track(guint index, Itdb_Track *t) {
    const char *title = t->title ? t->title : "";
    const char *artist = t->artist ? t->artist : "";
    const char *album = t->album ? t->album : "";
    unsigned long long size = (unsigned long long)t->size;
    unsigned long long length = (unsigned long long)t->tracklen;

    /* Delimiter is TAB; Python side also accepts the older helper format. */
    printf("%u\t%u\t%s\t%s\t%s\t%llu\t%llu\n",
           index, (unsigned)t->mediatype, title, artist, album, size, length);
}

static int write_db(Itdb_iTunesDB *db) {
    if (!itdb_write(db, NULL)) {
        fprintf(stderr, "ERROR: could not write iPod database\n");
        return 0;
    }
    return 1;
}

static int remove_track(Itdb_iTunesDB *db, Itdb_Track *track) {
    char *filename = itdb_filename_on_ipod(track);
    gboolean file_removed = TRUE;

    /*
     * IMPORTANT:
     * db->tracks contains Itdb_Track objects.
     * db->playlists contains Itdb_Playlist objects.
     *
     * itdb_track_unlink()/itdb_track_remove() do not remove playlist
     * membership themselves, so remove the track from every playlist first.
     */
    for (GList *p = db->playlists; p; p = p->next) {
        Itdb_Playlist *pl = p->data;
        if (!pl) continue;

        while (itdb_playlist_contains_track(pl, track)) {
            itdb_playlist_remove_track(pl, track);
        }
    }

    if (filename) {
        if (g_file_test(filename, G_FILE_TEST_EXISTS)) {
            if (g_remove(filename) != 0) {
                fprintf(stderr, "WARNING: could not remove iPod file: %s\n", filename);
                file_removed = FALSE;
            }
        }
        g_free(filename);
    } else {
        fprintf(stderr, "WARNING: no physical iPod filename found for track\n");
        file_removed = FALSE;
    }

    itdb_track_remove(track);

    /*
     * Database removal succeeded even if the physical file was already
     * missing. Returning success here lets libgpod write the corrected DB.
     */
    (void)file_removed;
    return 1;
}

static Itdb_iTunesDB *load_db(const char *mount) {
    GError *error = NULL;
    Itdb_iTunesDB *db = itdb_parse(mount, &error);

    if (!db) {
        if (error) {
            fprintf(stderr, "ERROR: %s\n", error->message);
            g_error_free(error);
        } else {
            fprintf(stderr, "ERROR: could not read iPod database\n");
        }
    }
    return db;
}



static int device_write_supported(Itdb_Device *device) {
    const Itdb_IpodInfo *info = itdb_device_get_ipod_info(device);
    if (!info) return 0;

    const char *model_name = itdb_info_get_ipod_model_name_string(info->ipod_model);
    const char *generation = itdb_info_get_ipod_generation_string(info->ipod_generation);

    char *model_l = g_ascii_strdown(model_name ? model_name : "", -1);
    char *generation_l = g_ascii_strdown(generation ? generation : "", -1);

    /* Never write to iOS-family devices. */
    if (strstr(model_l, "iphone") ||
        strstr(model_l, "ipad") ||
        strstr(model_l, "ipod touch") ||
        strstr(generation_l, "iphone") ||
        strstr(generation_l, "ipad") ||
        strstr(generation_l, "ipod touch")) {
        g_free(model_l);
        g_free(generation_l);
        return 0;
    }

    /* libgpod 0.8.x does not provide the backend we need for later nanos. */
    if (strstr(model_l, "nano") &&
        (strstr(generation_l, "6th") || strstr(generation_l, "7th"))) {
        g_free(model_l);
        g_free(generation_l);
        return 0;
    }

    gboolean known = (model_name && *model_name) || (generation && *generation);
    g_free(model_l);
    g_free(generation_l);
    return known ? 1 : 0;
}
static int command_info(const char *mount) {
    Itdb_iTunesDB *db = load_db(mount);
    if (!db) return 1;

    const Itdb_IpodInfo *info = itdb_device_get_ipod_info(db->device);
    if (!info) {
        fprintf(stderr, "ERROR: libgpod could not identify the iPod model\n");
        itdb_free(db);
        return 1;
    }

    const char *model = info->model_number ? info->model_number : "";
    const char *model_name = itdb_info_get_ipod_model_name_string(info->ipod_model);
    const char *generation = itdb_info_get_ipod_generation_string(info->ipod_generation);

    printf("model_number\t%s\n", model);
    printf("model_name\t%s\n", model_name ? model_name : "");
    printf("generation\t%s\n", generation ? generation : "");

    itdb_free(db);
    return 0;
}

static int command_list(const char *mount) {
    Itdb_iTunesDB *db = load_db(mount);
    if (!db) return 1;

    guint i = 0;
    for (GList *p = db->tracks; p; p = p->next) {
        Itdb_Track *t = p->data;
        if (!t) continue;
        print_track(i++, t);
    }

    itdb_free(db);
    return 0;
}

static int command_delete_index(const char *mount, guint target) {
    Itdb_iTunesDB *db = load_db(mount);
    if (!db) return 1;
    if (!device_write_supported(db->device)) {
        fprintf(stderr, "ERROR: this iPod is not supported for write operations by this backend\n");
        itdb_free(db);
        return 1;
    }

    guint i = 0;
    Itdb_Track *target_track = NULL;

    for (GList *p = db->tracks; p; p = p->next) {
        Itdb_Track *t = p->data;
        if (!t) continue;
        if (i++ == target) {
            target_track = t;
            break;
        }
    }

    if (!target_track) {
        fprintf(stderr, "ERROR: track index %u does not exist\n", target);
        itdb_free(db);
        return 1;
    }

    fprintf(stderr, "INFO: deleting track %u: %s\n",
            target, target_track->title ? target_track->title : "(untitled)");

    remove_track(db, target_track);
    int ok = write_db(db);
    itdb_free(db);
    return ok ? 0 : 1;
}

static int command_delete_type(const char *mount, int type) {
    Itdb_iTunesDB *db = load_db(mount);
    if (!db) return 1;
    if (!device_write_supported(db->device)) {
        fprintf(stderr, "ERROR: this iPod is not supported for write operations by this backend\n");
        itdb_free(db);
        return 1;
    }

    GList *to_remove = NULL;
    for (GList *p = db->tracks; p; p = p->next) {
        Itdb_Track *t = p->data;
        if (!t) continue;

        if (type == -1 ||
            (type == 1 && t->mediatype == ITDB_MEDIATYPE_AUDIO) ||
            (type == 2 && t->mediatype == ITDB_MEDIATYPE_AUDIOBOOK)) {
            to_remove = g_list_prepend(to_remove, t);
        }
    }

    guint removed = 0;
    for (GList *p = to_remove; p; p = p->next) {
        remove_track(db, p->data);
        removed++;
    }
    fprintf(stderr, "INFO: removed %u track(s)\n", removed);
    g_list_free(to_remove);

    int ok = write_db(db);
    itdb_free(db);
    return ok ? 0 : 1;
}

static int add_track(const char *mount, const char *file, const char *cover) {
    GError *error = NULL;
    Itdb_iTunesDB *db = itdb_parse(mount, &error);
    if (!db) {
        if (error) {
            fprintf(stderr, "ERROR: %s\n", error->message);
            g_error_free(error);
        }
        return 1;
    }

    if (!device_write_supported(db->device)) {
        fprintf(stderr, "ERROR: this iPod is not supported for write operations by this backend\n");
        itdb_free(db);
        return 1;
    }

    Itdb_Track *t = itdb_track_new();
    if (!t) {
        fprintf(stderr, "ERROR: could not allocate track\n");
        itdb_free(db);
        return 1;
    }

    const char *ext = strrchr(file, '.');
    int audiobook = ext && (!g_ascii_strcasecmp(ext, ".m4b"));

    t->mediatype = audiobook ? ITDB_MEDIATYPE_AUDIOBOOK : ITDB_MEDIATYPE_AUDIO;
    t->remember_playback_position = audiobook ? 1 : 0;
    t->skip_when_shuffling = audiobook ? 1 : 0;

    const char *v;
    if ((v = getenv("IPOD_TITLE"))) t->title = g_strdup(v);
    if ((v = getenv("IPOD_ARTIST"))) t->artist = g_strdup(v);
    if ((v = getenv("IPOD_ALBUM"))) t->album = g_strdup(v);
    if ((v = getenv("IPOD_GENRE"))) t->genre = g_strdup(v);
    if ((v = getenv("IPOD_YEAR"))) t->year = (guint)strtoul(v, NULL, 10);
    if ((v = getenv("IPOD_LENGTH_MS"))) t->tracklen = (guint)strtoul(v, NULL, 10);
    if ((v = getenv("IPOD_TRACK"))) t->track_nr = (guint)strtoul(v, NULL, 10);
    if ((v = getenv("IPOD_COMMENT"))) t->comment = g_strdup(v);
    if ((v = getenv("IPOD_ALBUM_ARTIST"))) t->albumartist = g_strdup(v);

    itdb_track_add(db, t, -1);
    itdb_cp_track_to_ipod(t, file, &error);

    if (error) {
        fprintf(stderr, "ERROR: %s\n", error->message);
        g_error_free(error);
        itdb_free(db);
        return 1;
    }

    if (cover && *cover) {
        if (!itdb_track_set_thumbnails(t, cover)) {
            fprintf(stderr, "WARNING: could not attach cover artwork\n");
        }
    }

    if (!write_db(db)) {
        itdb_free(db);
        return 1;
    }

    itdb_free(db);
    return 0;
}

int main(int argc, char **argv) {
    if (argc < 3) {
        fprintf(stderr,
                "Usage:\n"
                "  %s info <mount>\n"
                "  %s list <mount>\n"
                "  %s delete-index <mount> <index>\n"
                "  %s delete-music <mount>\n"
                "  %s delete-audiobooks <mount>\n"
                "  %s delete-all <mount>\n"
                "  %s add <mount> <file> [cover]\n",
                argv[0], argv[0], argv[0], argv[0], argv[0], argv[0], argv[0]);
        return 2;
    }

    const char *command = argv[1];

    if (!strcmp(command, "info")) {
        return command_info(argv[2]);
    }

    if (!strcmp(command, "list")) {
        return command_list(argv[2]);
    }

    if (!strcmp(command, "delete-index") && argc >= 4) {
        return command_delete_index(argv[2], (guint)strtoul(argv[3], NULL, 10));
    }

    if (!strcmp(command, "delete-music")) {
        return command_delete_type(argv[2], 1);
    }

    if (!strcmp(command, "delete-audiobooks")) {
        return command_delete_type(argv[2], 2);
    }

    if (!strcmp(command, "delete-all")) {
        return command_delete_type(argv[2], -1);
    }

    if (!strcmp(command, "add") && argc >= 4) {
        return add_track(argv[2], argv[3], argc >= 5 ? argv[4] : NULL);
    }

    fprintf(stderr, "ERROR: unknown command\n");
    return 2;
}
