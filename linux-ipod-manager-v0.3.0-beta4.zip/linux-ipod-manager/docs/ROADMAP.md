# Roadmap

## 0.1

- [x] GTK/Tk desktop GUI
- [x] MP3 import
- [x] M4B audiobook import
- [x] Metadata via ffprobe
- [x] Embedded cover extraction
- [x] Audiobook media type
- [x] Track deletion
- [x] Bulk deletion
- [x] Mounted iPod discovery
- [x] Debian/Ubuntu/Zorin installation script

## 0.2

- [ ] Automatic iPod model identification
- [ ] Compatibility warnings in the GUI
- [ ] Database backup before every write
- [ ] Better error reporting
- [ ] Playlist support
- [ ] Track number / year display from database
- [ ] German/English language switch

## Packaging

- [x] Portable build scripts
- [x] GitHub Actions CI
- [x] GitHub Actions AppImage pipeline
- [ ] Validate AppImage on multiple distributions

## Future backends

The GUI should remain independent of the storage backend.

Potential future work:

- nano 6G backend
- nano 7G backend
- improved shuffle support
- database repair tools
- import/export playlists
- artwork management
- drag and drop
