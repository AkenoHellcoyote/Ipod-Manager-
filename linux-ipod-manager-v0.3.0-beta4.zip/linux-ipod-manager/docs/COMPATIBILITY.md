# Compatibility

## Project scope

Linux iPod Manager is intended for **classic, non-iOS iPods**.

The key distinction is the storage/database architecture, not simply the word "iPod" in the product name.

## Current backend

Version 0.1 uses libgpod 0.8.x.

This gives good coverage for the traditional iTunesDB-based iPods, but libgpod is not a universal backend for every later non-iOS nano.

### Practical target

| Family | Status |
|---|---|
| iPod 1G–3G | Target / legacy |
| iPod 4G / Photo | Target |
| iPod 5G / Video | Target |
| iPod 5.5G | Target |
| iPod Classic | Target |
| iPod mini | Target |
| iPod nano 1G | Target |
| iPod nano 2G | Target |
| iPod nano 3G | Target |
| iPod nano 4G | Target |
| iPod nano 5G | Special / requires testing |
| iPod nano 6G | Not supported by libgpod 0.8.3 |
| iPod nano 7G | Separate backend required |
| iPod shuffle | Depends on generation/backend |
| iPod touch | Out of scope |
| iPhone | Out of scope |
| iPad | Out of scope |

## Design rule

An unknown or unsupported iPod must be treated as **read-only / unsupported** rather than being written to blindly.

Future releases can add additional backends without replacing the GUI.


## Detection

The manager now asks libgpod for:

- model number
- model name
- generation
- whether the device belongs to the iPhone/iPod touch/iPad family

Unknown or unsupported devices are not granted write access by the GUI.
