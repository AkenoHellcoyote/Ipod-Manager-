#!/usr/bin/env python3
import json
import sys
import os
import re
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

VERSION = "0.3.0-beta1"
APP_NAME = f"Linux iPod Manager v{VERSION}"
if getattr(sys, "frozen", False):
    BASE_DIR = Path(sys.executable).resolve().parent
else:
    BASE_DIR = Path(__file__).resolve().parent

# Development/source install: helper is next to this script.
# AppImage/PyInstaller: helper may be one directory above the bundled GUI.
HELPER = BASE_DIR / "ipod-media-helper"
if not HELPER.exists():
    HELPER = BASE_DIR.parent / "ipod-media-helper"

MEDIA_MUSIC = 1
MEDIA_AUDIOBOOK = 8

def human_size(value):
    try:
        value = int(value)
    except Exception:
        return "?"
    units = ["B", "KB", "MB", "GB", "TB"]
    n = float(value)
    for unit in units:
        if n < 1024 or unit == units[-1]:
            return f"{n:.1f} {unit}"
        n /= 1024
    return "?"

def human_time(ms):
    try:
        seconds = max(0, int(ms) // 1000)
    except Exception:
        return "--:--"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"

def run_command(args, env=None):
    return subprocess.run(
        [str(x) for x in args],
        capture_output=True,
        text=True,
        env=env,
    )

def mounted_ipods():
    candidates = []
    roots = [
        Path("/media") / os.environ.get("USER", ""),
        Path("/run/media") / os.environ.get("USER", ""),
    ]
    for root in roots:
        if not root.exists():
            continue
        for p in root.iterdir():
            if not p.is_dir():
                continue
            if (p / "iPod_Control").is_dir():
                candidates.append(p)
    return candidates

def metadata(path):
    cmd = [
        "ffprobe", "-v", "error",
        "-show_entries",
        "format=duration:format_tags=title,artist,album,album_artist,genre,date,track,comment",
        "-of", "json", str(path)
    ]
    result = run_command(cmd)
    data = {}
    try:
        parsed = json.loads(result.stdout)
        fmt = parsed.get("format", {})
        data.update(fmt.get("tags", {}) or {})
        data["duration"] = float(fmt.get("duration", 0) or 0)
    except Exception:
        data["duration"] = 0

    def get(*names):
        for name in names:
            for k, v in data.items():
                if k.lower() == name.lower() and v not in (None, ""):
                    return str(v)
        return ""

    track = get("track")
    track_num = 0
    if track:
        m = re.match(r"(\d+)", track)
        if m:
            track_num = int(m.group(1))

    year = 0
    date = get("date")
    if date:
        m = re.search(r"(19|20)\d{2}", date)
        if m:
            year = int(m.group(0))

    return {
        "title": get("title") or path.stem,
        "artist": get("artist"),
        "album": get("album"),
        "album_artist": get("album_artist"),
        "genre": get("genre"),
        "comment": get("comment"),
        "year": year,
        "track": track_num,
        "duration_ms": int(data.get("duration", 0) * 1000),
    }

def extract_cover(path):
    fd, tmp = tempfile.mkstemp(suffix=".jpg", prefix="ipod-cover-")
    os.close(fd)
    cover = Path(tmp)
    cmd = [
        "ffmpeg", "-y", "-v", "error",
        "-i", str(path),
        "-an", "-c:v", "mjpeg", "-frames:v", "1",
        str(cover)
    ]
    result = run_command(cmd)
    if result.returncode == 0 and cover.exists() and cover.stat().st_size > 0:
        return cover
    try:
        cover.unlink()
    except FileNotFoundError:
        pass
    return None

def parse_device_info(text):
    info = {}
    for line in text.splitlines():
        if "\t" in line:
            key, value = line.split("\t", 1)
            info[key.strip()] = value.strip()
    return info

def device_status(info):
    if not info:
        return ("Unbekanntes iPod-Modell", "unknown")

    generation = info.get("generation", "")
    model = info.get("model_name", "")
    combined = f"{generation} {model}".lower()

    if any(x in combined for x in ("iphone", "ipad", "ipod touch")):
        return ("iOS-Gerät – außerhalb des Projektumfangs", "ios")

    # libgpod 0.8.x does not provide the backend we need for later nanos.
    # Generation strings are normally of the form "6th Generation iPod Nano".
    if re.search(r"\b6(?:th|\.?)\b", generation, re.IGNORECASE) and "nano" in generation.lower():
        return (f"{model or generation} – derzeit nicht unterstützt", "unsupported")
    if re.search(r"\b7(?:th|\.?)\b", generation, re.IGNORECASE) and "nano" in generation.lower():
        return (f"{model or generation} – separater Backend erforderlich", "unsupported")

    if generation or model:
        return (f"{model or 'iPod'} {generation}".strip() + " – libgpod-Backend", "supported")

    return ("iPod erkannt, Modell unbekannt – keine Schreiboperationen", "unknown")

def parse_helper_output(text):
    rows = []
    for line in text.splitlines():
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) >= 7:
            try:
                idx, media, title, artist, album, size, length = parts[:7]
                rows.append({
                    "index": int(idx),
                    "media": int(media),
                    "title": title,
                    "artist": artist,
                    "album": album,
                    "size": int(size),
                    "length": int(length),
                })
                continue
            except ValueError:
                pass

        parts = line.split("|")
        if len(parts) >= 8:
            try:
                rows.append({
                    "index": int(parts[0]),
                    "media": int(parts[1]),
                    "title": parts[2],
                    "artist": parts[3],
                    "album": parts[4],
                    "size": int(parts[5]),
                    "length": int(parts[6]),
                })
            except ValueError:
                pass
    return rows

class IpodManager(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1100x650")
        self.minsize(850, 500)

        self.mount = tk.StringVar()
        self.status = tk.StringVar(value="Kein iPod ausgewählt")
        self.device_info_text = tk.StringVar(value="")
        self.storage = tk.StringVar(value="Speicher: –")
        self.tracks = []
        self.device_state = "unknown"

        self.build_ui()
        self.refresh_mounts()

    def build_ui(self):
        top = ttk.Frame(self, padding=10)
        top.pack(fill="x")

        ttk.Label(top, text="iPod:").pack(side="left")
        self.mount_combo = ttk.Combobox(top, textvariable=self.mount, width=60)
        self.mount_combo.pack(side="left", padx=8, fill="x", expand=True)
        self.mount_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh_list())

        ttk.Button(top, text="Suchen", command=self.refresh_mounts).pack(side="left", padx=3)
        ttk.Button(top, text="Ordner…", command=self.choose_mount).pack(side="left", padx=3)

        info = ttk.Frame(self, padding=(10, 0, 10, 10))
        info.pack(fill="x")
        ttk.Label(info, textvariable=self.status).pack(side="left")
        ttk.Label(info, textvariable=self.device_info_text).pack(side="left", padx=18)
        ttk.Label(info, textvariable=self.storage).pack(side="right")

        columns = ("type", "title", "artist", "album", "duration", "year", "size")
        self.tree = ttk.Treeview(self, columns=columns, show="headings", selectmode="extended")
        headings = {
            "type": "Typ",
            "title": "Titel",
            "artist": "Interpret",
            "album": "Album",
            "duration": "Länge",
            "year": "Jahr",
            "size": "Größe",
        }
        widths = {"type": 100, "title": 280, "artist": 180, "album": 220,
                  "duration": 90, "year": 70, "size": 100}
        for col in columns:
            self.tree.heading(col, text=headings[col])
            self.tree.column(col, width=widths[col], anchor="w")
        self.tree.pack(fill="both", expand=True, padx=10)

        buttons = ttk.Frame(self, padding=10)
        buttons.pack(fill="x")
        ttk.Button(buttons, text="MP3 hinzufügen…", command=self.add_music).pack(side="left", padx=3)
        ttk.Button(buttons, text="Hörbuch hinzufügen…", command=self.add_audiobook).pack(side="left", padx=3)
        ttk.Separator(buttons, orient="vertical").pack(side="left", fill="y", padx=8)
        ttk.Button(buttons, text="Ausgewählte löschen", command=self.delete_selected).pack(side="left", padx=3)
        ttk.Button(buttons, text="Alle Musik löschen", command=self.delete_music).pack(side="left", padx=3)
        ttk.Button(buttons, text="Alle Hörbücher löschen", command=self.delete_audiobooks).pack(side="left", padx=3)
        ttk.Button(buttons, text="Alle Medien löschen", command=self.delete_all).pack(side="left", padx=3)
        ttk.Button(buttons, text="Aktualisieren", command=self.refresh_list).pack(side="right", padx=3)

    def refresh_mounts(self):
        found = mounted_ipods()
        values = [str(p) for p in found]
        if self.mount.get() and self.mount.get() not in values:
            values.insert(0, self.mount.get())
        self.mount_combo["values"] = values

        if found:
            self.mount.set(str(found[0]))
            self.refresh_list()
        elif self.mount.get():
            self.refresh_list()
        else:
            self.status.set("Kein gemounteter iPod gefunden")

    def choose_mount(self):
        path = filedialog.askdirectory(title="iPod-Mountpoint auswählen")
        if path:
            p = Path(path)
            if not (p / "iPod_Control").is_dir():
                messagebox.showerror(APP_NAME, "Der ausgewählte Ordner sieht nicht wie ein iPod aus.\n\nEs fehlt iPod_Control.")
                return
            self.mount.set(str(p))
            self.refresh_list()

    def check_ready(self):
        mount = self.mount.get().strip()
        if not mount or not Path(mount).is_dir():
            messagebox.showwarning(APP_NAME, "Bitte zuerst einen gemounteten iPod auswählen.")
            return None
        if not (Path(mount) / "iPod_Control").is_dir():
            messagebox.showerror(APP_NAME, "Der Mountpoint enthält kein iPod_Control-Verzeichnis.")
            return None
        if not HELPER.exists():
            messagebox.showerror(APP_NAME, f"Backend fehlt:\n{HELPER}")
            return None
        return mount

    def identify_device(self, mount):
        result = run_command([HELPER, "info", mount])
        info = parse_device_info(result.stdout)
        label, state = device_status(info)
        self.device_state = state
        self.device_info_text.set(label)

        if state == "ios":
            self.status.set("Nicht unterstützt: iOS-Gerät")
        elif state == "unsupported":
            self.status.set("Gerät erkannt, aber kein Schreib-Backend vorhanden")
        elif state == "unknown":
            self.status.set("iPod erkannt, Modell konnte nicht sicher bestimmt werden")
        else:
            self.status.set("Unterstützter iPod erkannt")

        return state

    def refresh_list(self):
        mount = self.check_ready()
        if not mount:
            return
        state = self.identify_device(mount)
        result = run_command([HELPER, "list", mount])
        self.tracks = parse_helper_output(result.stdout)

        for item in self.tree.get_children():
            self.tree.delete(item)

        for row in self.tracks:
            media = "HÖRBUCH" if row["media"] == MEDIA_AUDIOBOOK else "MUSIK"
            self.tree.insert("", "end", iid=str(row["index"]), values=(
                media,
                row["title"],
                row["artist"],
                row["album"],
                human_time(row["length"]),
                "",
                human_size(row["size"]),
            ))

        self.status.set(f"{len(self.tracks)} Titel gefunden")
        self.update_storage(mount)

    def update_storage(self, mount):
        try:
            usage = shutil.disk_usage(mount)
            used = usage.used
            total = usage.total
            self.storage.set(
                f"Speicher: {human_size(used)} / {human_size(total)} "
                f"({used / total * 100:.1f} %)"
            )
        except Exception:
            self.storage.set("Speicher: –")

    def add_music(self):
        self.add_files([".mp3"], "MP3 hinzufügen")

    def add_audiobook(self):
        self.add_files([".m4b"], "Hörbuch hinzufügen")

    def add_files(self, extensions, title):
        mount = self.check_ready()
        if not mount:
            return

        if self.device_state != "supported":
            messagebox.showwarning(
                APP_NAME,
                "Schreibzugriffe sind für dieses Gerät derzeit nicht freigegeben.\n\n"
                "Das schützt unbekannte oder nicht unterstützte iPods vor einer möglichen Datenbankbeschädigung."
            )
            return

        files = filedialog.askopenfilenames(
            title=title,
            filetypes=[("Unterstützte Dateien", " ".join("*" + e for e in extensions)),
                       ("Alle Dateien", "*.*")]
        )
        if not files:
            return

        for filename in files:
            path = Path(filename)
            if path.suffix.lower() not in extensions:
                messagebox.showwarning(APP_NAME, f"Übersprungen: {path.name}\nNicht unterstütztes Format.")
                continue

            meta = metadata(path)
            env = os.environ.copy()
            env.update({
                "IPOD_TITLE": meta["title"],
                "IPOD_ARTIST": meta["artist"],
                "IPOD_ALBUM": meta["album"],
                "IPOD_ALBUM_ARTIST": meta["album_artist"],
                "IPOD_GENRE": meta["genre"],
                "IPOD_YEAR": str(meta["year"]),
                "IPOD_TRACK": str(meta["track"]),
                "IPOD_LENGTH_MS": str(meta["duration_ms"]),
                "IPOD_COMMENT": meta["comment"],
            })

            cover = extract_cover(path)
            try:
                result = run_command(
                    [HELPER, "add", mount, path, cover or ""],
                    env=env
                )
            finally:
                if cover:
                    try:
                        cover.unlink()
                    except FileNotFoundError:
                        pass

            if result.returncode != 0:
                messagebox.showerror(
                    APP_NAME,
                    f"Fehler beim Hinzufügen von {path.name}:\n\n{result.stderr.strip() or result.stdout.strip()}"
                )
                return

        self.refresh_list()
        messagebox.showinfo(APP_NAME, f"{len(files)} Datei(en) wurden verarbeitet.")

    def selected_indices(self):
        return sorted((int(i) for i in self.tree.selection()), reverse=True)

    def delete_selected(self):
        mount = self.check_ready()
        if not mount:
            return
        if self.device_state != "supported":
            messagebox.showwarning(APP_NAME, "Löschen ist für dieses Gerät derzeit nicht freigegeben.")
            return
        indices = self.selected_indices()
        if not indices:
            messagebox.showinfo(APP_NAME, "Bitte mindestens einen Titel auswählen.")
            return

        if not messagebox.askyesno(APP_NAME, f"{len(indices)} ausgewählte Titel wirklich löschen?"):
            return

        for idx in indices:
            result = run_command([HELPER, "delete-index", mount, str(idx)])
            if result.returncode != 0:
                messagebox.showerror(APP_NAME, result.stderr.strip() or "Löschen fehlgeschlagen.")
                break
        self.refresh_list()

    def delete_music(self):
        self.delete_category("delete-music", "Alle Musikstücke löschen?")

    def delete_audiobooks(self):
        self.delete_category("delete-audiobooks", "Alle Hörbücher löschen?")

    def delete_all(self):
        self.delete_category("delete-all", "WIRKLICH ALLE Medien auf dem iPod löschen?")

    def delete_category(self, command, question):
        mount = self.check_ready()
        if not mount:
            return
        if self.device_state != "supported":
            messagebox.showwarning(APP_NAME, "Änderungen sind für dieses Gerät derzeit nicht freigegeben.")
            return
        if not messagebox.askyesno(APP_NAME, question):
            return
        result = run_command([HELPER, command, mount])
        if result.returncode != 0:
            messagebox.showerror(APP_NAME, result.stderr.strip() or "Löschen fehlgeschlagen.")
        self.refresh_list()

if __name__ == "__main__":
    if "--version" in sys.argv or "-v" in sys.argv:
        print(f"{APP_NAME}")
        raise SystemExit(0)
    IpodManager().mainloop()
