# Hardware test

This build has not been declared a release yet. It is a hardware-test build.

## First test

On the Zorin/Ubuntu machine:

```bash
cd ~/Downloads/linux-ipod-manager
./install.sh
```

Then connect and mount the iPod and start **Linux iPod Manager**.

Check first:

1. The application starts.
2. The iPod is detected automatically.
3. The model/generation appears in the status line.
4. Existing tracks are listed.

Do not delete anything during the first test.

## Build expectations

The helper is compiled against the installed libgpod headers and GdkPixbuf headers. The current Ubuntu/Zorin libgpod header exposes:

```c
gchar *itdb_filename_on_ipod (Itdb_Track *track);
gboolean itdb_track_set_thumbnails_from_pixbuf (Itdb_Track *track,
                                                GdkPixbuf *pixbuf);
```

The source is written to match those signatures.

After a successful build, the next test is a single MP3 import, followed by a single M4B import with embedded artwork.
