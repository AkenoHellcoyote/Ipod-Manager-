#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

ARCH="$(uname -m)"
if [ "$ARCH" != "x86_64" ]; then
    echo "This AppImage build script currently targets x86_64."
    exit 1
fi

command -v python3 >/dev/null || { echo "python3 is required"; exit 1; }
command -v gcc >/dev/null || { echo "gcc is required"; exit 1; }
command -v pkg-config >/dev/null || { echo "pkg-config is required"; exit 1; }
pkg-config --exists libgpod-1.0 gdk-pixbuf-2.0 || {
    echo "libgpod-1.0 and gdk-pixbuf-2.0 development files are required."
    exit 1
}

python3 -m venv .build-venv
.build-venv/bin/pip install --upgrade pip pyinstaller

rm -rf build dist AppDir
mkdir -p AppDir/usr/bin AppDir/usr/share/applications AppDir/usr/share/icons/hicolor/scalable/apps

# Build the native backend.
gcc -O2 -Wall -Wextra \
    -o AppDir/usr/bin/ipod-media-helper \
    src/ipod-media-helper.c \
    $(pkg-config --cflags --libs libgpod-1.0 gdk-pixbuf-2.0)

# Package Python/Tk into a self-contained directory.
.build-venv/bin/pyinstaller \
    --noconfirm \
    --clean \
    --onedir \
    --name ipod-manager \
    src/ipod-manager.py

cp -a dist/ipod-manager/. AppDir/usr/bin/ipod-manager/
# Also provide a simple /usr/bin entry for the desktop file.
ln -sfn ipod-manager/ipod-manager AppDir/usr/bin/ipod-manager-launcher

# ffmpeg and ffprobe are runtime requirements of the GUI for metadata/artwork.
# Bundle them into the AppImage so an end user does not need to install ffmpeg.
command -v ffmpeg >/dev/null || { echo "ffmpeg is required to build the AppImage"; exit 1; }
command -v ffprobe >/dev/null || { echo "ffprobe is required to build the AppImage"; exit 1; }
cp "$(command -v ffmpeg)" AppDir/usr/bin/ffmpeg
cp "$(command -v ffprobe)" AppDir/usr/bin/ffprobe

cp resources/linux-ipod-manager.svg AppDir/usr/share/icons/hicolor/scalable/apps/linux-ipod-manager.svg
sed 's#^Icon=.*#Icon=linux-ipod-manager#' desktop/linux-ipod-manager.desktop \
    > AppDir/usr/share/applications/linux-ipod-manager.desktop

if [ ! -x "$ROOT/linuxdeploy-x86_64.AppImage" ]; then
    echo "Downloading official linuxdeploy AppImage..."
    curl -fL \
      -o linuxdeploy-x86_64.AppImage \
      https://github.com/linuxdeploy/linuxdeploy/releases/download/continuous/linuxdeploy-x86_64.AppImage
    chmod +x linuxdeploy-x86_64.AppImage
fi

if [ ! -x "$ROOT/appimagetool-x86_64.AppImage" ]; then
    echo "Downloading official appimagetool AppImage..."
    curl -fL \
      -o appimagetool-x86_64.AppImage \
      https://github.com/AppImage/appimagetool/releases/download/continuous/appimagetool-x86_64.AppImage
    chmod +x appimagetool-x86_64.AppImage
fi

./linuxdeploy-x86_64.AppImage \
    --appdir AppDir \
    --desktop-file AppDir/usr/share/applications/linux-ipod-manager.desktop \
    --icon-file AppDir/usr/share/icons/hicolor/scalable/apps/linux-ipod-manager.svg \
    --executable AppDir/usr/bin/ipod-media-helper

VERSION="$(cat VERSION | tr -d '\n')"
ARCH=x86_64 ./appimagetool-x86_64.AppImage \
    AppDir \
    "Linux-iPod-Manager-${VERSION}-x86_64.AppImage"

echo
echo "Built: Linux-iPod-Manager-${VERSION}-x86_64.AppImage"
